package com.example.handmouse

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import java.util.concurrent.Executors

class BlinkService : LifecycleService() {
    companion object { @Volatile var running = false }

    private var landmarker: FaceLandmarker? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val detector = BlinkDetector()
    private var lastFrame = 0L

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("bs", "Blink Scroll", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "bs")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("🟢 Blink Scroll فعال است")
            .setContentText("۲ پلک = پست بعدی  |  ۳ پلک = پست قبلی")
            .setOngoing(true).build()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
        ServiceCompat.startForeground(this, 1, n, type)

        landmarker = createFaceLandmarker(this) { onResult(it) }
        if (landmarker == null) { stopSelf(); return }
        running = true
        startCamera()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(executor) { proxy ->
                val now = SystemClock.uptimeMillis()
                if (now - lastFrame >= 50) {
                    lastFrame = now
                    landmarker?.detectAsync(BitmapImageBuilder(proxy.toRotatedBitmap()).build(), now)
                }
                proxy.close()
            }
            val provider = future.get()
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onResult(r: FaceLandmarkerResult) {
        val dir = detector.update(blinkScore(r), SystemClock.uptimeMillis())
        if (dir != 0) GestureAccessibilityService.instance?.scroll(dir > 0)
    }

    override fun onDestroy() { running = false; landmarker?.close(); executor.shutdown(); super.onDestroy() }
}
