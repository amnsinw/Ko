package com.example.handmouse

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class GestureAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: GestureAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** next=true: انگشت روی صفحه به بالا کشیده می‌شه (پست بعدی) */
    fun scroll(next: Boolean) {
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val a = m.heightPixels * 0.72f
        val b = m.heightPixels * 0.28f
        val path = Path().apply {
            if (next) { moveTo(x, a); lineTo(x, b) } else { moveTo(x, b); lineTo(x, a) }
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 250)).build()
        dispatchGesture(g, null, null)
    }
}
