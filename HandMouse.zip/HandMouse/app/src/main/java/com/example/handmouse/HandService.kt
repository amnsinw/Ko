package com.example.handmouse

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.os.SystemClock
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.Executors

class HandService : LifecycleService() {
    private var landmarker: HandLandmarker? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val track = ArrayDeque<Pair<Long, Float>>()
    private var lastFire = 0L
    private var lastFrame = 0L

    // تنظیمات حساسیت
    private val windowMs = 350L      // بازه‌ی بررسی حرکت
    private val threshold = 0.12f    // جابه‌جایی لازم (نسبت به ارتفاع تصویر)
    private val cooldownMs = 800L    // فاصله‌ی بین دو اسکرول

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("hm", "Hand Mouse", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "hm")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Hand Mouse فعال است").setOngoing(true).build()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
        ServiceCompat.startForeground(this, 1, n, type)

        val f = File(filesDir, MainActivity.MODEL_NAME)
        if (!f.exists()) { stopSelf(); return }
        val bytes = f.readBytes()
        val buf = ByteBuffer.allocateDirect(bytes.size).put(bytes).also { it.rewind() }
        landmarker = HandLandmarker.createFromOptions(this,
            HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetBuffer(buf).build())
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setResultListener { r, _ -> onResult(r) }
                .build())
        startCamera()
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(executor) { proxy ->
                val now = SystemClock.uptimeMillis()
                if (now - lastFrame >= 50) { // حدود ۲۰ فریم بر ثانیه
                    lastFrame = now
                    val bmp = Bitmap.createBitmap(proxy.width, proxy.height, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(proxy.planes[0].buffer)
                    val m = Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }
                    val rot = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                    landmarker?.detectAsync(BitmapImageBuilder(rot).build(), now)
                }
                proxy.close()
            }
            val provider = future.get()
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onResult(r: HandLandmarkerResult) {
        val hand = r.landmarks().firstOrNull()
        if (hand == null || !isOpenPalm(hand)) { track.clear(); return }
        val now = SystemClock.uptimeMillis()
        track.addLast(now to hand[9].y())          // مرکز کف دست
        while (track.isNotEmpty() && now - track.first().first > windowMs) track.removeFirst()
        if (track.size < 3 || now - lastFire < cooldownMs) return
        val dy = track.last().second - track.first().second
        val svc = GestureAccessibilityService.instance ?: return
        when {
            dy < -threshold -> { svc.scroll(true); lastFire = now; track.clear() }   // دست به بالا
            dy > threshold -> { svc.scroll(false); lastFire = now; track.clear() }   // دست به پایین
        }
    }

    // کف باز = فعال. مشت کن تا دستت رو بدون اسکرول برگردونی.
    private fun isOpenPalm(h: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>): Boolean =
        listOf(8 to 6, 12 to 10, 16 to 14, 20 to 18).all { (tip, pip) -> h[tip].y() < h[pip].y() }

    override fun onDestroy() { landmarker?.close(); executor.shutdown(); super.onDestroy() }
    override fun onBind(intent: Intent): android.os.IBinder? = super.onBind(intent)
}
