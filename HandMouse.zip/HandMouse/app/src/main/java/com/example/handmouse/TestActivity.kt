package com.example.handmouse

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import java.util.concurrent.Executors

class TestActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private var landmarker: FaceLandmarker? = null
    private val detector = BlinkDetector()
    private val executor = Executors.newSingleThreadExecutor()
    private var lastFrame = 0L
    private var flash = ""
    private var flashUntil = 0L

    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) startCamera() else finish()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        stopService(android.content.Intent(this, BlinkService::class.java)) // دوربین آزاد بشه
        landmarker = createFaceLandmarker(this) { onResult(it) }
        if (landmarker == null) {
            Toast.makeText(this, "اول مدل را دانلود کن", Toast.LENGTH_LONG).show(); finish(); return
        }
        preview = PreviewView(this)
        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 18f; setPadding(32, 64, 32, 32)
            setBackgroundColor(0x99000000.toInt()); gravity = Gravity.CENTER
            text = "صورتت را جلوی دوربین بگیر و دو بار پلک بزن"
        }
        val ok = Button(this).apply {
            text = "✅ کار می‌کند، فعال کن"
            setOnClickListener { setResult(RESULT_OK); finish() }
        }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(preview, -1, -1)
            addView(status, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
            addView(ok, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(32, 32, 32, 96) })
        })
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
            startCamera() else camPerm.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(executor) { proxy ->
                val now = SystemClock.uptimeMillis()
                if (now - lastFrame >= 50) {
                    lastFrame = now
                    landmarker?.detectAsync(BitmapImageBuilder(proxy.toRotatedBitmap()).build(), now)
                }
                proxy.close()
            }
            val provider = future.get()
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, pv, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onResult(r: FaceLandmarkerResult) {
        val score = blinkScore(r)
        val now = SystemClock.uptimeMillis()
        val act = detector.update(score, now)
        if (act != 0) { flash = if (act > 0) "⏭ دو پلک ← پست بعدی" else "⏮ سه پلک ← پست قبلی"; flashUntil = now + 1500 }
        val eyes = when {
            score == null -> "❌ صورت دیده نمی‌شود"
            detector.isClosed -> "😑 چشم‌ها بسته"
            else -> "😐 چشم‌ها باز"
        }
        val txt = eyes + "\nپلک‌های شمرده‌شده: ${detector.pending}" + (if (now < flashUntil) "\n$flash" else "")
        runOnUiThread { status.text = txt }
    }

    override fun onDestroy() { landmarker?.close(); executor.shutdown(); super.onDestroy() }
}
