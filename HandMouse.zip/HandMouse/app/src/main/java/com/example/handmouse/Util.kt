package com.example.handmouse

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.camera.core.ImageProxy
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import java.io.File
import java.nio.ByteBuffer

fun ImageProxy.toRotatedBitmap(): Bitmap {
    val rs = planes[0].rowStride / 4
    val bmp = Bitmap.createBitmap(rs, height, Bitmap.Config.ARGB_8888)
    bmp.copyPixelsFromBuffer(planes[0].buffer)
    val m = Matrix().apply { postRotate(imageInfo.rotationDegrees.toFloat()) }
    return Bitmap.createBitmap(bmp, 0, 0, width, height, m, true)
}

fun createFaceLandmarker(ctx: Context, onResult: (FaceLandmarkerResult) -> Unit): FaceLandmarker? {
    val f = File(ctx.filesDir, MainActivity.MODEL_NAME)
    if (!f.exists()) return null
    val bytes = f.readBytes()
    val buf = ByteBuffer.allocateDirect(bytes.size).put(bytes).also { it.rewind() }
    return FaceLandmarker.createFromOptions(ctx,
        FaceLandmarker.FaceLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetBuffer(buf).build())
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumFaces(1)
            .setOutputFaceBlendshapes(true)
            .setResultListener { r, _ -> onResult(r) }
            .build())
}

/** امتیاز بسته بودن هر دو چشم (۰ تا ۱)؛ null یعنی صورتی دیده نشد */
fun blinkScore(r: FaceLandmarkerResult): Float? {
    val bs = r.faceBlendshapes().orElse(null)?.firstOrNull() ?: return null
    val l = bs.firstOrNull { it.categoryName() == "eyeBlinkLeft" }?.score() ?: return null
    val rt = bs.firstOrNull { it.categoryName() == "eyeBlinkRight" }?.score() ?: return null
    return minOf(l, rt) // چشمک یک‌چشمی حساب نشه
}

/** خروجی update: +1 دو پلک (پست بعدی)، -1 سه پلک (پست قبلی)، 0 هیچ */
class BlinkDetector {
    private val closeT = 0.55f      // بالاتر از این = چشم بسته
    private val openT = 0.35f       // پایین‌تر از این = چشم باز
    private val maxBlinkMs = 450L   // بسته‌ماندن طولانی‌تر = پلک حساب نمی‌شه
    private val gapMs = 700L        // فاصله‌ی مجاز بین پلک‌های یک حرکت
    private val cooldownMs = 1000L
    @Volatile var isClosed = false
        private set
    @Volatile var pending = 0
        private set
    private var closedAt = 0L
    private var lastEnd = 0L
    private var lastAction = 0L

    fun update(score: Float?, now: Long): Int {
        if (score == null) { isClosed = false }
        else if (!isClosed && score > closeT) { isClosed = true; closedAt = now }
        else if (isClosed && score < openT) {
            isClosed = false
            if (now - closedAt <= maxBlinkMs) { pending++; lastEnd = now } else pending = 0
        }
        if (pending > 0 && !isClosed && now - lastEnd > gapMs) {
            val c = pending; pending = 0
            if (now - lastAction < cooldownMs) return 0
            return when (c) { 2 -> { lastAction = now; 1 }; 3 -> { lastAction = now; -1 }; else -> 0 }
        }
        return 0
    }
}
