package com.example.handmouse

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.io.File
import java.net.URL

class MainActivity : ComponentActivity() {
    companion object {
        const val MODEL_NAME = "face_landmarker.task"
        const val MODEL_URL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task"
    }

    private lateinit var statusView: TextView
    private val ui = Handler(Looper.getMainLooper())

    private val testLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) ui.postDelayed({
            ContextCompat.startForegroundService(this, Intent(this, BlinkService::class.java))
            refresh(); ui.postDelayed({ refresh() }, 1500)
        }, 700) // کمی صبر تا دوربین آزاد بشه
    }
    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) openTest() else toast("دسترسی دوربین لازمه")
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        statusView = TextView(this).apply { textSize = 22f; gravity = Gravity.CENTER; setPadding(0, 0, 0, 48) }
        root.addView(statusView)
        fun btn(t: String, a: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { a() } })
        btn("۱) دانلود مدل") { downloadModel() }
        btn("۲) روشن کردن سرویس دسترسی‌پذیری") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("۳) تست دوربین و شروع") { startFlow() }
        btn("توقف") { stopService(Intent(this, BlinkService::class.java)); ui.postDelayed({ refresh() }, 500) }
        root.addView(TextView(this).apply { text = "\nدو پلک = پست بعدی\nسه پلک = پست قبلی"; gravity = Gravity.CENTER })
        setContentView(root)
        // هر بار اپ باز می‌شه، اگه همه چیز آماده‌ست اول تست دوربین رو نشون بده
        if (s == null && !BlinkService.running && ready()) startFlow()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun ready() = File(filesDir, MODEL_NAME).exists() && GestureAccessibilityService.instance != null

    private fun refresh() {
        statusView.text = if (BlinkService.running) "🟢 فعال است" else "⚪ غیرفعال"
    }

    private fun startFlow() {
        if (!File(filesDir, MODEL_NAME).exists()) return toast("اول مدل را دانلود کن")
        if (GestureAccessibilityService.instance == null) return toast("اول سرویس دسترسی‌پذیری را روشن کن")
        val hasCam = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (hasCam) openTest() else camPerm.launch(Manifest.permission.CAMERA)
    }

    private fun openTest() = testLauncher.launch(Intent(this, TestActivity::class.java))

    private fun downloadModel() {
        toast("در حال دانلود...")
        Thread {
            try {
                URL(MODEL_URL).openStream().use { i -> File(filesDir, MODEL_NAME).outputStream().use { i.copyTo(it) } }
                runOnUiThread { toast("مدل دانلود شد") }
            } catch (e: Exception) { runOnUiThread { toast("خطا: ${e.message}") } }
        }.start()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
