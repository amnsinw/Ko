package com.example.handmouse

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.io.File
import java.net.URL

class MainActivity : ComponentActivity() {
    companion object {
        const val MODEL_NAME = "hand_landmarker.task"
        const val MODEL_URL = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
    }

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it[Manifest.permission.CAMERA] == true) startHand() else toast("دسترسی دوربین لازمه")
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun btn(t: String, a: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { a() } })
        root.addView(TextView(this).apply {
            textSize = 16f
            text = "۱) مدل را دانلود کن\n۲) سرویس دسترسی‌پذیری Hand Mouse را روشن کن\n۳) شروع را بزن و برو سراغ اینستاگرام\n\nکف دست باز = فعال. دست را بالا ببر = پست بعدی، پایین = قبلی. مشت = توقف موقت."
        })
        btn("۱) دانلود مدل") { downloadModel() }
        btn("۲) تنظیمات دسترسی‌پذیری") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("۳) شروع") {
            perms.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS))
        }
        btn("توقف") { stopService(Intent(this, HandService::class.java)) }
        setContentView(root)
    }

    private fun startHand() {
        if (!File(filesDir, MODEL_NAME).exists()) return toast("اول مدل را دانلود کن")
        if (GestureAccessibilityService.instance == null) return toast("اول سرویس دسترسی‌پذیری را روشن کن")
        ContextCompat.startForegroundService(this, Intent(this, HandService::class.java))
        toast("فعال شد")
    }

    private fun downloadModel() {
        toast("در حال دانلود...")
        Thread {
            try {
                URL(MODEL_URL).openStream().use { i -> File(filesDir, MODEL_NAME).outputStream().use { i.copyTo(it) } }
                runOnUiThread { toast("مدل دانلود شد") }
            } catch (e: Exception) { runOnUiThread { toast("خطا: ${e.message}") } }
        }.start()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
